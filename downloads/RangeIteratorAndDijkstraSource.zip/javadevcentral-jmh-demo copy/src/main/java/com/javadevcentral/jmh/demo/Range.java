/**
 * Title:        Java Range Type
 * Description:  Implementation of the Range using the range iterator for the range type.
 * Copyright:    © Copyright (c) July 2020
 * 
 * @author       William F. Gilreath (will.f.gilreath@gmail.com)
 * @version      1.0
 *
 * This file is part of Java Range Type software project. Java Range Type is
 * free software; you can redistribute it and/or modify it under the terms of
 * the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package com.javadevcentral.jmh.demo;

import java.util.Iterator;

/**
 * Code copied from https://www.javacodegeeks.com/adding-range-type-in-java.html
 */

public final class Range implements Iterable<Integer> {

    private final int begin; //begin lower boundary index of range
    private final int close; //close upper boundary index of range
    private final int index; //index within range

    /**
     * Constructor creates range type with implicit increment index of one.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     *
     */
    public Range(final int begin, final int close) {
        this(begin, close, 1);
    }//end constructor

    /**
     * Constructor creates range type.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     * @param index Pass index or increment of the range type, but not zero.
     *
     */
    public Range(final int begin, final int close, final int index) {
        
        this.begin = begin;
        this.close = close;
        
        if(index == 0) 
            throw new java.lang.IllegalArgumentException("Range index must be positive integer.");
        
        this.index = index;
    }//end constructor

    /**
     * Method of creates range type with implicit increment index of one.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     *
     * @return Range Returns object that is an instance of Range class.
     */
    public final static Range of(final int begin, final int close) {
        return new Range(begin, close);
    }//end of

    /**
     * Method of creates range type with explicit incremental index.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     * @param index Pass index or increment of the range type, but not zero.
     *
     * @return Range Returns object that is an instance of Range class.
     */
    public final static Range of(final int begin, final int close, final int index) {
        return new Range(begin, close, index);
    }//end of

    /**
     * Method to creates range type with implicit increment index of one.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     *
     * @return Range Returns object that is an instance of Range class.
     */
    public final static Range to(final int begin, final int close) {
        return new Range(begin, close+1);
    }//end to

    /**
     * Method to creates range type with explicit incremental index.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     * @param index Pass index or increment of the range type, but not zero.
     *
     * @return Range Returns object that is an instance of Range class.
     */
    public final static Range to(final int begin, final int close, final int index) {
        return new Range(begin, close+1, index);
    }//end of

    /**
     * Method range creates range type with implicit increment index of one.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     *
     * @return Range Returns object that is an instance of Range class.
     */
    public final static Range range(final int begin, final int close) {
        return Range.of(begin, close+1);
    }//end range

    /**
     * Method range creates range type with explicit incremental index.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     * @param index Pass index or increment of the range type, but not zero.
     *
     * @return Range Returns object that is an instance of Range class.
     */
    public final static Range range(final int begin, final int close, final int index) {
        return Range.of(begin, close+1, index);
    }//end range

    /**
     * Method series creates range type with implicit increment index of one.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     *
     * @return Range Returns object that is an instance of Range class.
     */
    public final static Range series(final int begin, final int close) {
        return Range.to(begin, close+1);
    }//end series

    /**
     * Method series creates range type with explicit incremental index.
     *
     * @param begin Pass begin or start of the range type.
     * @param close Pass close or end of the range type.
     * @param index Pass index or increment of the range type, but not zero.
     *
     * @return Range Returns object that is an instance of Range class.
     */
    public final static Range series(final int begin, final int close, final int index) {
        return Range.to(begin, close+1, index);
    }//end series

    /**
     * Check if a value is within the range of the range type.
     *
     * @param int Pass primitive integer value to check.
     *
     * @return boolean Returns a Boolean true or false.
     */
    public final boolean in(final int val){
             
        if(val < this.begin || val > this.close) return false;  //val within range 
             
        return (((val - this.begin) % this.index) == 0); //val reachable by index
        
    }//end in

    /**
     * Create an iterator object of Integer type.
     *
     * @return Iterator<Integer> Returns instance as type Integer for the iterator.
     */
    public Iterator<Integer> iterator() {
        return new RangeIterator<>(this);
    }//end iterator

    /**
     * Get the beginning or starting index of the range type
     *
     * @return int Returns primitive integer for the first or head value in the range.
     */
    public int getBegin() {
        return this.begin;
    }//end getBegin

    /**
     * Get the ending or closing index of the range type
     *
     * @return int Returns primitive integer for the last or tail value in the range.
     */
    public int getClose() {
        return this.close;
    }//end getClose

    /**
     * Get the current index within the range type
     *
     * @return int Returns primitive integer for the index within the range.
     */
    public int getIndex() {
        return this.index;
    }//end getIndex

}//end class Range
