package com.javadevcentral.jmh.demo;

import java.util.PrimitiveIterator;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Measurement;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Warmup;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
public class RangeVsForNextBenchmark {
  @Benchmark
  @Fork(value = 2)
  @Measurement(iterations = 10, time = 1)
  @Warmup(iterations = 5, time = 1)
  public void forRange() {
    long dummy = 0;
    for (PrimitiveIterator.OfInt intr = range(0, 40, 1); intr.hasNext();) {
      dummy++;
    }
  }

  @Benchmark
  @Fork(value = 2)
  @Measurement(iterations = 10, time = 1)
  @Warmup(iterations = 5, time = 1)
  public void forGenericRange() {
    long dummy = 0;
    for (Integer i : Range.of(0, 40, 1)) {
      dummy++;
    }
  }

  @Benchmark
  @Fork(value = 2)
  @Measurement(iterations = 10, time = 1)
  @Warmup(iterations = 5, time = 1)
  public void forNext() {
    long dummy = 0;
    for (int i = 0; i < 4000; i++) {
      dummy++;
    }
  }

  public static PrimitiveIterator.OfInt range(int minInclusive, int maxExclusive, int step) {
    return IntStream.iterate(minInclusive, i -> i < maxExclusive, i -> i + step).iterator();
  }
}
