/**
 * Title:        Java Range Type
 * Description:  Implementation of the RangeIterator for the range type.
 * Copyright:    © Copyright (c) July 2020
 * 
 * @author       William F. Gilreath (will.f.gilreath@gmail.com)
 * @version      1.0
 * 
 * This file is part of Java Range Type software project. Java Range Type is
 * free software; you can redistribute it and/or modify it under the terms of
 * the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package com.javadevcentral.jmh.demo;

import java.util.Iterator;
import java.lang.Integer;
import java.util.NoSuchElementException;

/**
 * Code copied from https://www.javacodegeeks.com/adding-range-type-in-java.html
 */
public final class RangeIterator<T> implements Iterator<T> {

    private int idx   = -1;   //increment index
    private int pos   = 0;    //position in range
    
    private int begin = -1;   //begin value of range
    private int close = -1;   //close value of range

    /**
     * Constructor creates range iterator with range object instance of Range.
     *
     * @param range Pass an instance of Range class to iterate upon.
     *
     */
    public RangeIterator(final Range range) {
        this.begin = range.getBegin();
        this.close = range.getClose();
        this.idx   = range.getIndex();
    }//end constructor 

    /**
     * Determines if there is next element.
     *
     * @return boolean Returns true or false if there is a next element.
     */
    public boolean hasNext() {
        return (this.begin + this.pos) < this.close;  //[begin...pos... < close)
    }//end hasNext

    /**
     * Get the next element or value.
     *
     * @return T Returns generic type of value in the range.
     */
    public T next() {
        if (!this.hasNext()) {
            throw new NoSuchElementException("No further values in range.");
        }//end if

        @SuppressWarnings("unchecked")
        T val = (T) Integer.valueOf(this.begin + this.pos);
        this.pos = this.pos + this.idx;
        
        return val;
    }//end next

    /**
     * Method determines if a generic value is next in the iterator.
     *
     * @param T Pass a generic value to validate is next in the sequence.
     *
     * @return boolean Returns true or false.
     */
    public boolean isNext(T val){
        val = next();
        return this.hasNext();
    }//end isNext

    /**
     * Remove an element from the iterator range.
     * 
     * Not implemented as it does not apply to a range type.
     *
     */
    public void remove() {
        throw new UnsupportedOperationException("RangeIterator: Remove is not supported.");
    }//end remove

}//end class RangeIterator