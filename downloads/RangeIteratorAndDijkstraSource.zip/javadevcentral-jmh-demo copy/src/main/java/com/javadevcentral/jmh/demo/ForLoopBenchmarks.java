package com.javadevcentral.jmh.demo;

import static com.javadevcentral.jmh.demo.Range.range;

import java.util.PrimitiveIterator;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Measurement;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Warmup;
import org.openjdk.jmh.infra.Blackhole;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
public class ForLoopBenchmarks {
  @Benchmark
  @Fork(value = 2)
  @Measurement(iterations = 10, time = 1)
  @Warmup(iterations = 5, time = 1)
  public void forLoopPrimitiveInt(Blackhole bh) {
    for (int i=0; i<100000; i++) {
      bh.consume(i);
    }
  }

  @Benchmark
  @Fork(value = 2)
  @Measurement(iterations = 10, time = 1)
  @Warmup(iterations = 5, time = 1)
  public void forLoopWrapperInt(Blackhole bh) {
    for (Integer i=0; i<100000; i++) {
      bh.consume(i);
    }
  }

  @Benchmark
  @Fork(value = 2)
  @Measurement(iterations = 10, time = 1)
  @Warmup(iterations = 5, time = 1)
  public void forLoopPrimitiveIterator(Blackhole bh) {
    for(PrimitiveIterator.OfInt itr = IntStream.iterate(0, i -> i < 100000, i -> i + 1).iterator(); itr.hasNext();) {
      bh.consume(itr.next());
    }
  }

  @Benchmark
  @Fork(value = 2)
  @Measurement(iterations = 10, time = 1)
  @Warmup(iterations = 5, time = 1)
  public void forLoopGenericRange(Blackhole bh) {
    for (Integer i : range(0, 100000, 1)) {
      bh.consume(i);
    }
  }
}
